# test.py

from represent import BaseModel

class Model(BaseModel):

    def __init__(self) -> None:

        self.self = self
        self.type = type(self)

        self.values = [1, 2, 3]
        self.objects = {
            'self': self.self,
            'type': self.type
        }
    # end __init__
# Model

model = Model()

print(model)