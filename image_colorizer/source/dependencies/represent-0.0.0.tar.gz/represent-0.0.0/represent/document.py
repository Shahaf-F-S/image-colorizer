# document.py

# noinspection PyUnresolvedReferences
from represent import *

from represent.base import document

class Documentation:
    """"""
# end Documentation

document(Documentation)